import { BrowserRouter as Switch, Route } from 'react-router-dom';
import Layout from 'components/Layout';
import ScrollToTop from 'utils/scrollToTop';
import HomePage from 'containers/HomePage';
import GalleryPage from 'containers/Gallery';
import LorePage from 'containers/LorePage';
import AboutPage from 'containers/AboutPage';
import AuctionPage from 'containers/AuctionPage';
import MintPage from 'containers/MntPage';
import ApplicationPage from 'containers/ApplicationPage';

const Routes = () => (
  <>
    <Switch>
      <Layout>
        <ScrollToTop />
        <Route exact path="/" component={HomePage} />
        <Route exact path="/gallery" component={GalleryPage} />
        <Route exact path="/lore" component={LorePage} />
        <Route exact path="/about" component={AboutPage} />
        <Route exact path="/auction" component={AuctionPage} />
        <Route exact path="/mint" component={MintPage} />
        <Route exact path="/application" component={ApplicationPage} />
        {/* <Route exact path="/" render={() => <Redirect to="/home" />} /> */}
      </Layout>
    </Switch>
  </>
);

export default Routes;
