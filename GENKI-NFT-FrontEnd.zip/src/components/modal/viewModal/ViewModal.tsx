import './viewModal.scss';
import Bounce from 'react-reveal/Bounce';
import { useEffect, useState } from 'react';

interface Props {
  showModal: boolean;
  setShowModal?: any;
}

const ViewModal: React.FC<Props> = ({ showModal, setShowModal }) => {
  
  const [isStart, setIsStart] = useState(false);
  useEffect(() => {
    if (showModal) {
      setTimeout(() => {
        setIsStart(true);
      }, 100);
    }
  }, [setIsStart, showModal]);
  const onClose = () => {
    setIsStart(false);
    setTimeout(() => {
      setShowModal(false);
    }, 800);
  };
  // const [isLoaded, setIsLoaded] = useState(false);
  // const handleImageLoaded = () => {
  //   if(!isLoaded) setIsLoaded(true);
  //   setIsLoaded(true);
  // }

  return (
    <div className={showModal === true ? 'viewModal active' : 'viewModal'}>
      <Bounce opposite when={isStart}>
        <div className="modelContent">
          <button className="connectModalCloseButton" onClick={onClose}>
            <i className="fas fa-times"></i>
          </button>
          <div className="connectWalletWrapper">
            <div className="top" >
            <div style={{padding:'57% 0 0 0', position:'relative', overflow : 'hidden'}}>

              <iframe 
              src="https://www.youtube.com/embed/KhRpMIgyv-0?autoplay=0&fs=0&iv_load_policy=3&showinfo=0&rel=0&cc_load_policy=0&start=0&end=0&origin=http://youtubeembedcode.com"
              width="1920" 
              height="1080" 
              frameBorder="0" 
              allow="autoplay; fullscreen; picture-in-picture" 
              allowFullScreen = {true} 
              style={{position:'absolute',top:'0%',left:0,width:'100%',height:'100%'}} 
              title="Genki_Teaser_SampleMusic.mp4"></iframe>
            </div>
              <script src="https://player.vimeo.com/api/player.js"></script>
              {/* <video className={'backVideo'} autoPlay={true} loop muted={true} playsInline>
                <source src="/assets/genkiLoop.mp4" type="video/mp4" onLoad={handleImageLoaded}/>
              </video> */}
            </div>
            
          </div>
        </div>
      </Bounce>
    </div>
  );
};
export default ViewModal;
