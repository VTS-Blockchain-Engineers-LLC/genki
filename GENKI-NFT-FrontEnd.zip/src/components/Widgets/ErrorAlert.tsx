import PropTypes from 'prop-types';
import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(theme => ({
  alertText: {
    color: '#ff0000'
  },
  title: {
    letterSpacing: 0.2,
    fontSize: 14,
    fontWeight: 700,
    fontFamily: "'Josefin Sans', sans-serif",
    [theme.breakpoints.down('xs')]: {
      fontSize: 10,
    },
  },
  root: {
    display: 'flex',
    alignItems: 'center',
    padding: '7px 20px',
    marginTop : -20,
    borderRadius : 15,
    backgroundColor : '#ff000033',
    [theme.breakpoints.down('xs')]: {
      marginTop : -10,
    },
  },
}));


const ErrorAlert = ({ title, description, show, alertType }) => {
  const classes = useStyles();

  return (
    show && (
      <span className={classes.root} >
        <p className={clsx(classes.alertText, classes.title)}>{title}</p>
        <p className={classes.alertText}>{description}</p>
      </span>
    )
  );
};

ErrorAlert.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.string,
  avatar: PropTypes.node,
  alertType: PropTypes.string,
};

ErrorAlert.defaultProps = {
  avatar: '',
};

export default ErrorAlert;
