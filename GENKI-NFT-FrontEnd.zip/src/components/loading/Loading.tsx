import "./loading.scss";
// type PropsType = {
//   isLoading?: boolean;
// };

export default function Loading(props) {
  const {isLoading} = props;
  return (
    <div
      className={`${isLoading ? "loading_page activeLoading" : "loading_page"}`}
    >
      <img className="logoIcon" alt="" src="assets/logo.png" />
      <p className="txt">Loading ...</p>
    </div>
  );
}
