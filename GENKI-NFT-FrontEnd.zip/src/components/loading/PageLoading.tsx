import "./loading.scss";
// type PropsType = {
//   isLoading?: boolean;
// };

export default function PageLoading(props) {
  const {isLoading} = props;
  return (
    <div
      className={`${isLoading ? "loading_page1 activeLoading" : "loading_page1"}`}
    >
      
    </div>
  );
}
