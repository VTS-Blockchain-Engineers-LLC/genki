import './menu.scss';
import { HashLink } from 'react-router-hash-link';
type MenuType = {
  menuOpen: boolean;
  setMenuOpen(flag: boolean): void;
  children?: any;
};

export default function Menu({ menuOpen, setMenuOpen, children }: MenuType) {

  return (
    <div className={'menubar ' + (menuOpen && 'active')}>
      <div className="menuContent">
        <div className={menuOpen ? 'closeBtn active' : 'closeBtn'}  onClick={() => setMenuOpen(false)}>
          <span></span>    <span></span>   <span></span>
        </div>
        <div className="logo" onClick={() => setMenuOpen(false)}>
          <HashLink to="/">
            <img src="/assets/Genki_Logo_white 1.png" alt="" />
          </HashLink>
        </div>
        {children}
      </div>
    </div>
  );
}
