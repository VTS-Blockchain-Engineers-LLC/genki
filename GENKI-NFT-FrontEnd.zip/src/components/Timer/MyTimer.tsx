import "./btnDown.scss"
import { useState, useEffect } from 'react';

type TimeNumber = {
    startTime ? :number,
};
export default function MyTimer({ startTime }: TimeNumber) {
    const [days, setDays] = useState(0);
    const [hours, setHours] = useState(0);
    const [minutes, setMinutes] = useState(0);
    const [seconds, setSeconds] = useState(0);
    useEffect(() => {
        let myInterval = setInterval(() => {
            const currentDate: any = Date.now()/1000;
            const startDiff = startTime - currentDate;
            const dayNum = startDiff > 0 ? Math.floor(startDiff  / 60 / 60 / 24) : 0;
            const hourNum = startDiff > 0 ? Math.floor(startDiff  / 60 / 60) % 24 : 0;
            const minNum = startDiff > 0 ? Math.floor(startDiff  / 60) % 60 : 0;
            const secNum = startDiff > 0 ? Math.floor(startDiff ) % 60 : 0;

            if (currentDate < startTime) {
                setDays(dayNum);
                setHours(hourNum);
                setMinutes(minNum);
                setSeconds(secNum);
            }
            

        }, 100)
        return () => {
            clearInterval(myInterval);
        };

    }, [startTime]);

    return (
        <div className="myTimer">
            <span className="number">{days < 10 ? `0${days}` : days} : {hours < 10 ? `0${hours}` : hours} : {minutes < 10 ? `0${minutes}` : minutes} : {seconds < 10 ? `0${seconds}` : seconds} </span>
        </div>
    )
}