// import { useWeb3React } from '@web3-react/core';
import ConnectModal from 'components/modal/connectModal/ConnectModal';
import { useEffect, useState } from 'react';
import { HashLink } from 'react-router-hash-link';
// import { truncateWalletString } from 'utils';
import './footer.scss';
import AccountModal from 'components/modal/accountModal/AccountModal';
import { useLocation } from "react-router-dom";
type MenuType = {
  menuOpen?: boolean;
  setMenuOpen?(flag: boolean): void;
};

export default function Footer({ menuOpen, setMenuOpen }: MenuType) {
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showAcountModal, setShowAcountModal] = useState(false);

  // const [loginStatus, setLoginStatus] = useState(false);
  // const { connector, library, chainId, account, active } = useWeb3React();
  // useEffect(() => {
  //   const isLoggedin = account && active && chainId === parseInt(process.env.REACT_APP_NETWORK_ID, 10);
  //   setLoginStatus(isLoggedin);
    
  // }, [connector, library, account, active, chainId]);

  const [navId, setNavId] = useState("");
  const search = useLocation();
  useEffect(() => {
    
    if(search.hash.includes("#")){
      const hash = search.hash.replace("#", "");
      setNavId(hash);
    }else{
      const hash = search.pathname.replace("/", "");
      setNavId(hash);
    }
    
  }, [setNavId, search]);
  return (
    <div className="footer">
      <div className="footer-content">
        <div className="logo">
          <HashLink to="/">
            <img src="/assets/Genki_Logo_white 1.png" alt="" />
          </HashLink>
        </div>

        <div className="navList">
          <ul>

            <li className={navId === "gallery" ? "selected" : ""}>
              <HashLink to="/gallery" smooth>GALLERY</HashLink>
            </li>
            <li className={navId === "lore" ? "selected" : ""}>
              <HashLink to="/lore" smooth>LORE</HashLink>
            </li>
            {/* <li className={navId === "mint" ? "selected" : ""}>
              <HashLink to="/mint" smooth>MINT</HashLink>
            </li>
            <li className={navId === "auction" ? "selected" : ""}>
              <HashLink to="/auction" smooth>AUCTION</HashLink>
            </li>
             */}
            <li className={navId === "application" ? "selected" : ""}>
              <a href="https://superstarlist.genkiworld.xyz/" target={'_blank'} rel="noreferrer">WL APPLICATION</a>
            </li>
            <li className={navId === "application" ? "selected" : ""}>
              <a href="https://genki-nft.gitbook.io/genki-docs/" target={'_blank'} rel="noreferrer">WHITEPAPER</a>
            </li>
          <li className={navId === "about" ? "selected" : ""}>
            <HashLink to="/about" smooth>ABOUT</HashLink>
          </li>
          
        </ul>
      </div>

        <div className="btns">
          {/* <div className="connectBtn" onClick={() => !loginStatus ? setShowConnectModal(true) : setShowAcountModal(true)}>
            <img src="/assets/imgs/btn_01.png" alt="" />
            <p>{loginStatus ? truncateWalletString(account) : 'Connect Wallet'}</p>
          </div> */}
        </div>
        
        <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
        <AccountModal showAccountModal={showAcountModal} setShowAccountModal={setShowAcountModal} />
      </div>
    </div>
  );
}
