import PropTypes from 'prop-types';
import { useContext, useEffect, useState } from 'react';
import Topbar from './topbar/Topbar';
import { makeStyles } from '@material-ui/core/styles';
import ThemeContext from "theme/ThemeContext"
import SideBar from './SideBar/SideBar';
import Menu from 'components/menu/Menu';
import { useLocation } from 'react-router-dom';
import Loading from "components/loading/Loading";

const useStyles = makeStyles(theme => ({
  layout: {
    display: 'flex',
    flexDirection: 'column',
    minHeight: '100vh',
    position: 'relative',
    overflow: 'hidden',
    width: '100%',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      padding : 0,
    },
    
  },
  
  layoutContent: {
    width: '100%',
    display: 'flex',
    margin : '0 auto',
    zIndex : 1,
    [theme.breakpoints.down('xs')]: {
    },
  },
  back1: {
    width : '60vw',
    height : '60vw',
    borderRadius : '50%',
    backgroundImage: 'radial-gradient(#302f41 0%, #302f4100 50%)',
    left : '-30vw',
    top : '-30vw',
    zIndex : 1,
    position : 'absolute',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      width: '100%',
    },
  },

  back2: {
    width : '100vw',
    height : '100vw',
    borderRadius : '50%',
    backgroundImage: 'radial-gradient(#362e47 0%, #29314700 50%)',
    right : '-30vw',
    bottom : '-50vw',
    position : 'absolute',
    zIndex : 1,
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      width: '100%',
    },
  },
  sideBar: {
    width: '16vw',
    minWidth: 230,
    maxWidth: 300,
    padding: '13px 1.5vw',
    position: 'relative',
    marginRight : 15,
    background: '#fff',
    borderRadius : 20,
    boxShadow: "0px 16px 60px #00000008",
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      maxWidth: '100%',
      padding: '0px 20px',
      marginTop: 80,
    },
  },
  mainContent: {
    width: '100%',
    height : 'auto',
    margin : 0,
   
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      maxWidth: '100%',
      padding: 0,
    },
  },
  socials: {
    right : 30,
    bottom : 30,
    position : 'fixed',
    zIndex : 1,
    display : 'flex',
    [theme.breakpoints.down('xs')]: {
      display : 'none',
    },
    '& a':{
      width : 40,
      height : 40,
      display: 'flex',
      alignItems : 'center',
      justifyContent : 'center',
      background : '#fff',
      color : '#000',
      transition : 'all 0.7s ease',
      clipPath : 'polygon(0 0, 80% 0, 100% 20%, 100% 100%, 0 100% )',
      marginLeft : 10,
      '&:hover':{
        color : '#888'
      }
    }
  },
}));
const Layout = ({ children }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const classes = useStyles();
  const { theme } = useContext(ThemeContext)
  
  const [navId, setNavId] = useState("");
  const search = useLocation();
  useEffect(() => {
    
      const hash = search.pathname.replace("/", "");
      setNavId(hash);
    
  }, [setNavId, search]);

  const [isLoading, setIsLoading] = useState(true);

  window.onload = () => {
    setIsLoading(false);
  };

  return (
    <>
      <Loading isLoading={isLoading} />
      <div className={`${classes.layout} ${theme}`}>
        
        <div className={classes.layoutContent}>
          
        <div className={`${classes.back1}`} style = {{zIndex : navId === '' ? 1:0}}></div>
        <div className={`${classes.back2}`} style = {{zIndex : navId === '' ? 1:0}}></div>
          <div className={`${classes.mainContent}`}>
            {navId !== 'application' && <Topbar menuOpen={menuOpen} setMenuOpen={setMenuOpen} />}
            
            {children}

            {navId !== 'application' && <div className={`${classes.socials}`}>
              <a href="https://discord.gg/genkiofficial" className="discord" target="_blank" rel="noreferrer">
                <i className="fab fa-discord"></i>
              </a>

              <a href="https://twitter.com/Genki_NFT" className="twitter" target="_blank" rel="noreferrer">
                <i className="fab fa-twitter"></i>
              </a>
            </div>}
          </div>
        </div>
        
       
      </div>
      <Menu menuOpen={menuOpen} setMenuOpen={setMenuOpen} children={<SideBar menuOpen={menuOpen} setMenuOpen={setMenuOpen} />}/>
    </>
  );
};

Layout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Layout;
