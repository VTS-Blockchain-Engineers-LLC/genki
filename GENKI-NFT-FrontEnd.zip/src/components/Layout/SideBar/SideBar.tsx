// import { useWeb3React } from '@web3-react/core';
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import './style.scss';
import { HashLink } from 'react-router-hash-link';
// import { truncateWalletString } from 'utils';
import ConnectModal from 'components/modal/connectModal/ConnectModal';
import AccountModal from 'components/modal/accountModal/AccountModal';
type MenuType = {
  menuOpen?: boolean;
  setMenuOpen?(flag: boolean): void;
};
export default function SideBar({ menuOpen, setMenuOpen }: MenuType) {
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showAcountModal, setShowAcountModal] = useState(false);

  // const [loginStatus, setLoginStatus] = useState(false);
  // const { connector, library, chainId, account, active } = useWeb3React();
  // useEffect(() => {
  //   const isLoggedin = account && active && chainId === parseInt(process.env.REACT_APP_NETWORK_ID, 10);
  //   setLoginStatus(isLoggedin);
    
  // }, [connector, library, account, active, chainId]);

  const search = useLocation();

  const [navId, setNavId] = useState("");
  useEffect(() => {
    
    if(search.hash.includes("#")){
      const hash = search.hash.replace("#", "");
      setNavId(hash);
    }else{
      const hash = search.pathname.replace("/", "");
      setNavId(hash);
    }
    
  }, [setNavId, search]);

  return (
    <>
      <div className="sideBar">
        <div className="title">
          <h1>BRING THE</h1>
          <h1 className='stroke'>ENERGY</h1>
        </div>
        <div className="navList" onClick={() => setMenuOpen(false)}>
          <ul>
            <li className={navId === "gallery" ? "selected" : ""}>
              <HashLink to="/gallery" smooth>GALLERY</HashLink>
            </li>
            <li className={navId === "lore" ? "selected" : ""}>
              <HashLink to="/lore" smooth>LORE</HashLink>
            </li>
            {/* <li className={navId === "mint" ? "selected" : ""}>
              <HashLink to="/mint" smooth>MINT</HashLink>
            </li>
            <li className={navId === "auction" ? "selected" : ""}>
              <HashLink to="/auction" smooth>AUCTION</HashLink>
            </li> */}
            
            <li className={navId === "application" ? "selected" : ""}>
              <a href="https://superstarlist.genkiworld.xyz/" target={'_blank'} rel="noreferrer">WL APPLICATION</a>
            </li>
            <li className={navId === "application" ? "selected" : ""}>
              <a href="https://genki-nft.gitbook.io/genki-docs/" target={'_blank'} rel="noreferrer">WHITEPAPER</a>
            </li>
            
            <li className={navId === "about" ? "selected" : ""}>
              <HashLink to="/about" smooth>ABOUT</HashLink>
            </li>
          </ul>
        </div>
        {/* <div className="btns">
          <div className="connectBtn" onClick={() => !loginStatus ? setShowConnectModal(true) : setShowAcountModal(true)}>
            <img src="/assets/imgs/btn_01.png" alt="" />
            <p>{loginStatus ? truncateWalletString(account) : 'Connect Wallet'}</p>
          </div>
        </div> */}
        <div className="logo_back"><img src="/assets/logo.png" alt="" /></div>
      </div>
      <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
        <AccountModal showAccountModal={showAcountModal} setShowAccountModal={setShowAcountModal} />
    </>
  );
}
