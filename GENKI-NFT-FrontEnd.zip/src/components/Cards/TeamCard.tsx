import { makeStyles } from '@material-ui/core/styles';
import { useEffect, useRef, useState } from 'react';

interface PropsType {
  item?: any;
  onLoad?: any;
}

const useStyles = makeStyles(theme => ({
  productWrapper: {
    maxWidth: 250,
    cursor: 'pointer',
    overflow: 'hidden',
    
    position: 'relative',
    [theme.breakpoints.down('xs')]: {
      maxWidth: 300,
      width : '100%',
      margin: 'auto',
    },
    '& .team-member': {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'column',
      position: 'relative',
      borderRadius : 10,
      overflow : 'hidden',
      boxShadow : '0px 8px 8px #00000055',
      marginBottom: 10,
      '& img': {
        width: '100%',
        objectFit: 'cover',
      
        [theme.breakpoints.down('xs')]: {
          display : 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        },
      },
    },

    '& .text': {
      padding: '10px 0px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection: 'column',
      transition : 'all 0.3s ease',
      [theme.breakpoints.down('xs')]: {
        width: '100% !important',
      },
      
      '& h3': {
        color : '#fff',
        fontWeight: 700,
        fontSize: 'min(0.8vw, 12px)',
        fontFamily: "'Montserrat', sans-serif",
        letterSpacing : '2px !important',
        marginBottom: 10,
        // whiteSpace : 'nowrap'
        [theme.breakpoints.down('xs')]: {
          fontSize: 10,
          letterSpacing : '0px !important',
        },
      },
      '& p': {
        color : '#8A8A87',
        fontWeight: 700,
        fontSize: 'min(0.8vw, 12px)',
        letterSpacing: '1px',
        marginBottom: 10,
        
        [theme.breakpoints.down('xs')]: {
          fontSize: 8,
        },
      },
      '& a': {
        color : '#FF4E4E',
        fontWeight: 700,
        fontSize: 12,
        letterSpacing: '1px',
        marginBottom: 10,
        
        [theme.breakpoints.down('xs')]: {
          fontSize: 8
        },
      },
    },

  },
}));


const TeamCard = ({ item, onLoad }: PropsType) => {
  const classes = useStyles();
  const [isLoaded, setIsLoaded] = useState(false);
  const handleLoad = ()=>{
    onLoad();
    setIsLoaded(true);
  }
  const nft_ref = useRef(null) 
  const [height, setHeight] = useState(0);
  window.onresize = ()=>{
    try {
      let width = nft_ref.current.getClientRects()[0].width
      setHeight(width)
      setTimeout(() => {
        if(nft_ref.current){
          let width = nft_ref.current.getClientRects()[0].width
          setHeight(width)
        }
      }, 300);
    } catch (e) {
      console.log(e);
    }
  }

  useEffect(() => {
    try {
      let width = nft_ref.current.getClientRects()[0].width
      setHeight(width)
      setTimeout(() => {
        if(nft_ref.current){
          let width = nft_ref.current.getClientRects()[0].width
          setHeight(width)
        }
      }, 300);
    } catch (e) {
      console.log(e);
    }
  }, [setHeight]);
  
  return (
    <div className={`${classes.productWrapper} card1`}>
      <div className="team-member" style = {{height : height}} ref = {nft_ref}>
      {
          item?.assetUrl && item?.assetUrl !== "" ? <img src={item?.assetUrl} alt="" onLoad={handleLoad}/> :
          <img src='/assets/imgs/empty.png' alt="" onLoad={handleLoad}/>
        }
        <img src='/assets/imgs/empty.png' alt="" style = {{position : 'absolute', top : 0, left : 0, opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
      </div>

      <div className="text" style = {{ opacity : isLoaded ? 1 : 0, }}>
        <h3 style={{letterSpacing : 4}}>{item?.name || ""}</h3>
        {item?.link1 && item?.link1 !== "" &&  <a href={item?.link1} target={'_blank'} rel="noreferrer" style={{color : '#FF4E4E99'}}> Void Zero Labs</a>}
        {item?.title && item?.title !== "" &&  <p>{item?.title || ""}</p>}
        {item?.link && item?.link !== "" &&  <a href={item?.link} target={'_blank'} rel="noreferrer">{item?.id || ""}</a>}
        
      </div>
    </div>
  );
};

export default TeamCard;
