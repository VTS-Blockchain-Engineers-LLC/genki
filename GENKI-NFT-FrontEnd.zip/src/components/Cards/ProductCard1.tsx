import { makeStyles } from '@material-ui/core/styles';
import { useEffect, useRef, useState } from 'react';

interface PropsType {
  item?: any;
  onLoad?: any;
}

const useStyles = makeStyles(theme => ({
  productWrapper: {
    maxWidth: 454,
    cursor: 'pointer',
    overflow: 'hidden',
    marginBottom: 30,
    position: 'relative',
    [theme.breakpoints.down('xs')]: {
      maxWidth: 150,
      // maxWidth: '90vw',
      margin: 'auto',
      minWidth: 150,
    },
    '& .nft-div': {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'column',
      position: 'relative',
      borderRadius : 10,
      overflow : 'hidden',
      background : '#d3d3d3',
      boxShadow : '0px 8px 8px #00000055',
      '& img': {
        width: '100%',
        // height: '17vw',
        // maxHeight : 256,
        objectFit: 'cover',
        transition : 'all 0.3s ease',
        [theme.breakpoints.down('xs')]: {
          display : 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        },
      },
      
    },

    '& .text': {
      padding: '10px 20px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexDirection: 'column',
      transition : 'all 0.3s ease',
      '@media screen and (max-width: 768px) and (orientation: portrait)': {
        width: '100% !important',
      },
      '& p': {
        color : '#8A8A87',
        fontWeight: 700,
        fontSize: 12,
        fontFamily: "'Montserrat', sans-serif",
        letterSpacing: '1.8px',
        [theme.breakpoints.down('xs')]: {
          fontSize: 8,
        },
      },
      '& h3': {
        color : '#fff',
        fontWeight: 700,
        fontSize: 12,
        fontFamily: "'Montserrat', sans-serif",
        letterSpacing: '2px',
        [theme.breakpoints.down('xs')]: {
          letterSpacing: '2px !important',
          fontSize: 10,
        },
      },
    },

  },
}));


const PropertyCard1 = ({ item, onLoad }: PropsType) => {
  const classes = useStyles();
  const [isLoaded, setIsLoaded] = useState(false);
  const handleLoad = ()=>{
    onLoad();
    setIsLoaded(true);
  }

  const [height, setHeight] = useState(0);
  window.onresize = ()=>{

    try {
      let width = nft_ref.current.getClientRects()[0].width
      setHeight(width)
      setTimeout(() => {
        if(nft_ref.current){
          let width = nft_ref.current.getClientRects()[0].width
          setHeight(width)
        }
      }, 300);
    } catch (e) {
      console.log(e);
    }
    

  }
  const nft_ref = useRef(null) 
  useEffect(() => {
    try {
      let width = nft_ref.current.getClientRects()[0].width
      setHeight(width)
      setTimeout(() => {
        if(nft_ref.current){
          let width = nft_ref.current.getClientRects()[0].width
          setHeight(width)
        }
      }, 300);
    } catch (e) {
      console.log(e);
    }
   
  }, [setHeight]);

  return (
    <div className={`${classes.productWrapper} `}>
      <div className="nft-div" ref = {nft_ref} style = {{height : height}}>
        {
          item?.assetUrl && item?.assetUrl !== "" ? <img src={item?.assetUrl} alt="" onLoad={handleLoad} style = {{opacity : isLoaded ? 1 : 0,}}/> :
            <div>
              Awaiting Design
            </div>
        }
        {/* <img src='/assets/imgs/empty.png' alt="" style = {{position : 'absolute', top : 0, left : 0, opacity : isLoaded ? 1 : 1, transition : 'all 0.3s ease'}}/> */}
      </div>

      <div className="text"  style = {{opacity : isLoaded ? 1 : 1}}>
        <p>GENKI</p>
        {item?.name && item?.name !== "" ? 
          <h3 style={{letterSpacing : 4}}>{item?.name || ""}</h3>:
          null
        }
      </div>
    </div>
  );
};

export default PropertyCard1;
