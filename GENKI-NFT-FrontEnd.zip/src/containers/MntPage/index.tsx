import { useWeb3React } from '@web3-react/core';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { useStyles } from './style';
import ConnectModal from 'components/modal/connectModal/ConnectModal';
import AccountModal from 'components/modal/accountModal/AccountModal';
import MyTimer from 'components/Timer/MyTimer';
// import PageLoading from 'components/loading/PageLoading';

const MintPage = () => {
  const classes = useStyles();
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showAcountModal, setShowAcountModal] = useState(false);

  const [isLoaded, setIsLoaded] = useState(true);
  const [count, setCount] = useState(0);
  const handleImageLoaded = () => {
    setCount(count + 1)
  }
  useEffect(() => {
    setIsLoaded(true);
    if (count === 3){
      setTimeout(() => {
        setIsLoaded(false);
      }, 0);
    }
   
  }, [setIsLoaded, count]);


  const [mintCount, setMintCount] = useState(0);
  const decreaseHandle = () => {
    if (mintCount > 0) {
        setMintCount(mintCount - 1)
    }
}
const increaseHandle = () => {
    let mintLimit = 30;
    if (mintCount < mintLimit) {
        setMintCount(mintCount + 1)
    }
}

  const [loginStatus, setLoginStatus] = useState(false);
  const { connector, library, chainId, account, active } = useWeb3React();
  
  useEffect(() => {
      const isLoggedin = account && active && chainId === parseInt(process.env.REACT_APP_NETWORK_ID, 10);
      setLoginStatus(isLoggedin);
  
  }, [connector, library, account, active, chainId]);
  
  const mintTokens = async () => {
    if (!loginStatus) {
        toast.error("Please connect wallet correctly!");
        return;
    }
   
  };
  return (
    <>
    {/* <PageLoading isLoading={isLoaded} /> */}
      <div className={`${classes.root}`} >
        <div className={classes.content}>
          <div className={classes.timer}>
            <MyTimer startTime={1668808800}/>
          </div>
          {!loginStatus ?
            <div className={classes.connectWallet}>
              <h4><span>/ /</span> PRIVATE WL MINT</h4>
              <button className="connectBtn"  onClick={() => !loginStatus ? setShowConnectModal(true) : setShowAcountModal(true)}>
                  <p>CONNECT WALLET</p>
                  <img src="/assets/imgs/btn_02.png" alt=""   onLoad = {handleImageLoaded}/>
              </button>
              <p>CONNECT WITH WALLET THAT WAS GRANTED WL</p>
            </div>:
            <>
              <div className={classes.mintPart}>
                <div className="mintCount">
                  <div className="row">
                      <button className="mintIncDec" disabled={false} onClick={decreaseHandle}>
                          <p><i className="fas fa-minus"></i></p>
                      </button>
                      <span className="mintCountValue" style={{}}>
                        <input type="number" value={mintCount}/>
                      </span>
                      {mintCount > 4 ?
                      <p>MAX</p>:
                      <button className="mintIncDec" disabled={false} onClick={increaseHandle}>
                          <p><i className="fas fa-plus"></i></p>
                      </button>}
                  </div>
                  <div className="row">
                    <button className="mintNow" onClick={mintTokens} disabled={false}>
                      <p>MINT</p>
                      <img src="/assets/imgs/btn_02.png" alt=""  onLoad = {handleImageLoaded} />
                    </button>
                  </div>
                <p className='desc'>Total cost: 1.0 ETH</p>
                    
                </div>
              </div>
              <img src="/assets/imgs/mint_banner.png" alt="" className={`${classes.bannerImg} pc`} onLoad = {handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
              
            </>
          }
          <img src="/assets/imgs/Captains_01.png" alt="" className={`${classes.bannerImg} mob`} onLoad = {handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
          <img src="/assets/imgs/lore_bg.png" alt="" className={classes.bannerBg} onLoad = {handleImageLoaded}/>
        </div>
        
      </div>
      <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
      <AccountModal showAccountModal={showAcountModal} setShowAccountModal={setShowAcountModal} />
    </>
  );
};

export default MintPage;
