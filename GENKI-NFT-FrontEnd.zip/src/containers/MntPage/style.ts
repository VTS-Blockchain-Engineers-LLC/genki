import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    borderRadius : 20,
    padding: 24,
    height : 'calc(100vh - 7rem)',
    position : 'relative',
    maxWidth : 1440,
    margin : 'auto',
    [theme.breakpoints.down('sm')]: {
      padding: 10,
      paddingTop: 0,
      paddingBottom: 0,
      height : 'calc(100vh - 5rem)',
    },
    '& .pc': {
      display: 'flex',
      [theme.breakpoints.down('xs')]: {
        display: 'none !important',
        
      },
    },
    '& .mob': {
      display: 'none !important',
      [theme.breakpoints.down('xs')]: {
        display: 'flex !important',
        
      },
    },
  },
  content: {
    width: '90%',
    display: 'flex',
    margin : 'auto',
    height : '100%',
    alignItems: 'center',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
    },
    
  },
  timer: {
    width: '90%',
    display: 'flex',
    margin : 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    position : 'absolute',
    top : '2rem',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      zIndex : 1,
      top : '56%',
    },
    
  },
  connectWallet: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
    margin : 'auto',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      position :'absolute',
      bottom : 10,
    },
    '& h4': {
      fontSize : 14,
      lineHeight : 1,
      fontWeight : 700,
      color : '#fff',
      letterSpacing: 5,
      fontFamily: "'Montserrat', sans-serif",
      marginBottom : 20,
      [theme.breakpoints.down('xs')]: {
        fontSize : 12,
        marginLeft : 0,
        textAlign :'center',
      },
      '& span': {
        color : '#D71314',
      }
      
    },
    '& p': {
      fontSize : 12,
      lineHeight : 1.5,
      fontWeight : 700,
      color : '#777',
      letterSpacing: 5,
      fontFamily: "'Montserrat', sans-serif",
      marginBottom : 20,
      marginTop : 20,
      width : 350,
      textAlign : 'center',
      [theme.breakpoints.down('xs')]: {
        fontSize : 10,
        marginLeft : 0,
        textAlign :'center',
        width : '90%',
      },
      '& span': {
        color : '#D71314',
      }
      
    },
    
    '& .connectBtn': {
      background : '#ffffff00',
      border : 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position : 'relative',
      margin : '0 10px',
      
      cursor : 'pointer',
      [theme.breakpoints.down('xs')]: {
      },
      
      '&:hover': {
        '& img': {
          filter : 'drop-shadow(0px 0px 5px #fff)'
        },
      },
      
      '& p': {
        fontSize : 28,
        fontWeight : 800,
        color : '#fff',
        fontFamily: "'Barlow Condensed', sans-serif",
        position : 'absolute',
        zIndex : 1,
        [theme.breakpoints.down('xs')]: {
          fontSize : 20,
         
        },
      },
      '& img': {
        height : 72,
        transition : 'all 0.7s ease',
        filter : 'drop-shadow(0px 8px 5px #000)',
        [theme.breakpoints.down('xs')]: {
          height : 55,
        },
      },
    },
  },
  mintPart: {
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'column',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      width: '100%',
      position :'absolute',
      bottom : 10,
    },

    '& .mintCount': {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column',
      paddingTop : 30,
      paddingBottom : 30,
      [theme.breakpoints.down('xs')]: {
        paddingTop : 20,
        paddingBottom : 20,
      },

      '& .row': {
        display: 'flex',
        alignItems: 'center',
        marginBottom : 10,
        [theme.breakpoints.down('xs')]: {
        },
        '& .mintCountValue': {
          display: 'flex',
          [theme.breakpoints.down('xs')]: {
          },
          '& input': {
            border : 'none',
            background : '#ffffff00',
            padding : '0px 20px',
            // height : 62,
            fontSize : 120,
            fontWeight : 800,
            maxWidth : 150,
            textAlign : 'center',
            color :'#fff',
            fontFamily: "'Barlow Condensed', sans-serif",
            [theme.breakpoints.down('xs')]: {
              fontSize : 40,
              maxWidth : 120,
            },
            '&:focus': {
              outline : 'none',
              [theme.breakpoints.down('xs')]: {
              },
            },
            
          },
         
          '& input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button': {
            display: 'none', 
          },
        },
        '& .mintIncDec': {
          backgroundImage : 'linear-gradient(135deg, #F4D8CE 0%, #FFAA7F 39.52%, #FE7850 71.1%, #FF5656 81.55%, #FF4C4C 100%), linear-gradient(135deg, #6D6D6D 0%, #212121 100%)',
          width: 62,
          height : 62,
          border : 'none',
          borderRadius :'50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition : 'all 0.7s ease',
          cursor : 'pointer',
          '&:hover': {
            boxShadow : '0px 0px 10px #fff',
          },
          [theme.breakpoints.down('xs')]: {
            width: 40,
            height : 40,
          },
          
        },
        '& p': {
          fontSize : 30,
          fontWeight : 800,
          color : '#fff',
          fontFamily: "'Montserrat', sans-serif",
      
          [theme.breakpoints.down('xs')]: {
            fontSize : 20,
          },
        },
      },
      '& .mintNow': {
        background : '#ffffff00',
        border : 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position : 'relative',
        margin : '0 10px',
        
        cursor : 'pointer',
        [theme.breakpoints.down('xs')]: {
        },
        
        
        '&:hover': {
          '& img': {
            filter : 'drop-shadow(0px 0px 5px #fff)'
          },
        },
        '& p': {
          fontSize : 30,
          fontWeight : 800,
          color : '#fff',
          fontFamily: "'Barlow Condensed', sans-serif",
          position : 'absolute',
          zIndex : 1,
          [theme.breakpoints.down('xs')]: {
            fontSize : 20,
          },
        },
        '& img': {
          height : 62,
          transition : 'all 0.7s ease',
          filter : 'drop-shadow(0px 8px 5px #000)',
          [theme.breakpoints.down('xs')]: {
            height : 40,
          },
        },
      },
      '& .desc': {
        fontSize : 12,
        fontWeight : 100,
        fontFamily: 'KozGoProRegular',
        color : '#fff',
        [theme.breakpoints.down('xs')]: {
          fontSize : 12,
        },
        '& span': {
          fontWeight : 800,
        }
      },
    },
    
    
  },
  
  bannerImg: {
    position:'absolute',
    left : '40%',
    bottom : 0,
    objectFit : 'cover',
    height : '100vh',
    filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '100vh',
    },
    [theme.breakpoints.down('lg')]: {
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      height : 'auto',
      width : '100vw',
      left : '0%',
      bottom : 'auto',
      top : 0,
      zIndex : -1,
      opacity : 0.7,
    },
  },

  bannerBg: {
    position:'absolute',
    objectFit : 'cover',
    filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    height : '45vh',
    left : '50%',
    transform : 'translate(-50%, 45%)',
    top : 0,
    zIndex : -1,
    [theme.breakpoints.down('xs')]: {
      display : 'none',
    },
  },
  
}));



export default useStyles;
