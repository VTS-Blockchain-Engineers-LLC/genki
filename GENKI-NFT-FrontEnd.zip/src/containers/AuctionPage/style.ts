import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    height : '100%',
    width: '100%',
    [theme.breakpoints.down('sm')]: {
      paddingTop: 0,
    },
  },
  bg1: {
    position:'absolute',
    left : '50%',
    top : 0,
    zIndex : -1,
    width : '100%',
    transform : 'translateX(-50%)',
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '100vh',
    },
    [theme.breakpoints.down('lg')]: {
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      paddingBottom: 20,
    },
  },
  bg2: {
    position:'absolute',
    left : '50%',
    top : 0,
    objectFit : 'cover',
    width : '100%',
    zIndex : -1,
    transform : 'translateX(-50%)',
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '100vh',
    },
    [theme.breakpoints.down('lg')]: {
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      paddingBottom: 20,
    },
  },

  mintPart: {
    
    width: 500,
    display: 'flex',
    alignItems: 'center',
    // justifyContent: 'center',
    flexDirection: 'column',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      width: '100%',
    },
    
    '& .state': {
      background: '#252525',
      width: '100%',
      height : 70,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position : 'relative',
      [theme.breakpoints.down('xs')]: {
        height : 50,
      },
      '& p': {
        fontSize : 14,
        fontWeight : 800,
        fontFamily: "'Montserrat', sans-serif",
        color : '#fff',
        letterSpacing : '4px',
        [theme.breakpoints.down('xs')]: {
          fontSize : 12,
        },
        '& span': {
          color : '#D71314',
        }
      },
      '& .price': {
        fontWeight : 500,
        position : 'absolute',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        left : 10,
        top : 10,
        marginBottom: theme.spacing(2),
        [theme.breakpoints.down('xs')]: {
          top : 5,
        },
        '& h4': {
          fontSize : 12,
          fontWeight : 500,
          color : '#fff',
          fontFamily: 'KozGoProRegular',
          [theme.breakpoints.down('xs')]: {
            fontSize : 10,
          },
        },
        '& h3': {
          fontSize : 22,
          fontWeight : 800,
          color : '#fff',
          fontFamily: "'Barlow Condensed', sans-serif",
          [theme.breakpoints.down('xs')]: {
            fontSize : 16,
          },
        },
      },
    },
    '& .mintCount': {
      background: '#191919',
      width: '100%',
      minHeight : 200,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'column',
      paddingTop : 30,
      paddingBottom : 30,
      [theme.breakpoints.down('xs')]: {
        paddingTop : 20,
        paddingBottom : 20,
        minHeight : 150,
      },

      '& .row': {
        display: 'flex',
        alignItems: 'center',
        marginBottom : 10,
        [theme.breakpoints.down('xs')]: {
        },
        '& .mintCountValue': {
          display: 'flex',
          [theme.breakpoints.down('xs')]: {
          },
          '& input': {
            border : 'none',
            background : '#ffffff00',
            padding : '0px 20px',
            height : 62,
            fontSize : 50,
            fontWeight : 800,
            maxWidth : 150,
            textAlign : 'center',
            color :'#fff',
            fontFamily: "'Barlow Condensed', sans-serif",
            [theme.breakpoints.down('xs')]: {
              fontSize : 40,
              maxWidth : 120,
            },
            '&:focus': {
              outline : 'none',
              [theme.breakpoints.down('xs')]: {
              },
            },
            
          },
         
          '& input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button': {
            display: 'none', 
          },
        },
        '& .mintIncDec': {
          backgroundImage : 'linear-gradient(135deg, #F4D8CE 0%, #FFAA7F 39.52%, #FE7850 71.1%, #FF5656 81.55%, #FF4C4C 100%), linear-gradient(135deg, #6D6D6D 0%, #212121 100%)',
          width: 62,
          height : 62,
          border : 'none',
          borderRadius :'50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          transition : 'all 0.7s ease',
          cursor : 'pointer',
          boxShadow : '0px 8px 10px #000',
          '&:hover': {
            boxShadow : '0px 8px 10px #000, 0px 0px 10px #fff',
          },
          [theme.breakpoints.down('xs')]: {
            width: 40,
            height : 40,
          },
          '& p': {
            fontSize : 30,
            fontWeight : 800,
            color : '#fff',
            [theme.breakpoints.down('xs')]: {
              fontSize : 20,
            },
          },
        },
      },
      '& .mintNow': {
        background : '#ffffff00',
        border : 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position : 'relative',
        margin : '0 10px',
        
        cursor : 'pointer',
        [theme.breakpoints.down('xs')]: {
        },
        
        
        '&:hover': {
          '& img': {
            filter : 'drop-shadow(0px 0px 5px #fff)'
          },
        },
        '& p': {
          fontSize : 30,
          fontWeight : 800,
          color : '#fff',
          fontFamily: "'Barlow Condensed', sans-serif",
          position : 'absolute',
          zIndex : 1,
          [theme.breakpoints.down('xs')]: {
            fontSize : 20,
          },
        },
        '& img': {
          height : 62,
          transition : 'all 0.7s ease',
          filter : 'drop-shadow(0px 8px 5px #000)',
          [theme.breakpoints.down('xs')]: {
            height : 40,
          },
        },
      },
      '& .desc': {
        fontSize : 12,
        fontWeight : 100,
        fontFamily: 'KozGoProRegular',
        color : '#fff',
        [theme.breakpoints.down('xs')]: {
          fontSize : 12,
        },
        '& span': {
          fontWeight : 800,
        }
      },
      '& .price': {
        fontWeight : 500,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        [theme.breakpoints.down('xs')]: {
          fontSize : 20,
        },
        '& h4': {
          fontSize : 12,
          fontWeight : 500,
          color : '#fff',
          fontFamily: 'KozGoProRegular',
          [theme.breakpoints.down('xs')]: {
            fontSize : 10,
          },
        },
        '& h3': {
          fontSize : 22,
          fontWeight : 800,
          color : '#fff',
          fontFamily: "'Barlow Condensed', sans-serif",
          [theme.breakpoints.down('xs')]: {
            fontSize : 20,
          },
        },
      },
      '& .eth': {
        marginLeft : 20,
        marginRight : -50,
        [theme.breakpoints.down('xs')]: {
        },
        '& h4': {
          fontSize : 12,
          fontWeight : 500,
          color : '#fff',
          fontFamily: 'KozGoProRegular',
          [theme.breakpoints.down('xs')]: {
            fontSize : 20,
          },
        },
        
      },
    },
    '& .banner': {
      height : '50%',
      [theme.breakpoints.down('xs')]: {
        display : 'none',
      },
    },
    '& .pc': {
      display: 'flex',
      [theme.breakpoints.down('xs')]: {
        display: 'none !important',
      },
    },
    '& .mob': {
      display: 'none !important',
      [theme.breakpoints.down('xs')]: {
        display: 'flex !important',
      },
    },
  },
  tablePart: {
    width: 'calc(100% - 530px)',
    marginLeft : 30,
    height : 'fit-content',
    maxHeight : '100%',
    display: 'flex',
    flexDirection: 'column',
    position : 'relative',
    backgroundSize : 'cover',
    backgroundColor : '#191919',
    [theme.breakpoints.down('xs')]: {
      marginLeft : 0,
      width: '100%',
      marginBottom : '1rem',
    },
    '& h2': {
      fontSize : 14,
      lineHeight : 1,
      fontWeight : 700,
      color : '#fff',
      letterSpacing: 5,
      fontFamily: "Montserrat-ExtraBold",
      marginLeft : 16,
      marginBottom : '3rem',
      [theme.breakpoints.down('xs')]: {
        fontSize : 16,
        marginLeft : 0,
        textAlign :'center',
      },
      '& span': {
        color : '#D71314',
      }
      
    },
    '& .stroke': {
      fontSize : 164,
      lineHeight : 1,
      fontWeight : 700,
      fontStyle : 'italic',
      fontFamily: "Montserrat-ExtraBold",
      color: 'transparent',
      textStroke: '1px #fff',
      textShadow : 'none',
      whiteSpace : 'nowrap',
      opacity : 0.1,
      position : 'absolute',
      left : '50%',
      top : 0,
      transform : 'translateX(-50%)',
      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        display: 'none',
      },
    },
  },

  content: {
    width: '100%',
    height : 'calc(100vh - 8em)',
    display: 'flex',
    maxWidth : 1440,
    margin : 'auto',
    position : 'relative',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
      height : 'calc(100vh - 5em)',
      flexDirection: 'column-reverse',
    },
   
  },
 
}));



export default useStyles;
