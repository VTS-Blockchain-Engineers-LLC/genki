import { makeStyles } from '@material-ui/core/styles';
import BasicTable from 'components/Table';

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
  },
  title: {
    color: '#000',
  },
  footer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background :'#252525',
    padding : 10,
    '& p': {
      fontSize: 14,
      fontWeight : 'normal',
      cursor: 'pointer',
      color: '#fff',
      fontFamily: 'KozGoProRegular',
      [theme.breakpoints.down('xs')]: {
        fontSize: 12,
      },
    },
  },
}));

const RankTable = ({ listings }) => {
  const classes = useStyles();

  const rows = [];

  for (let i = 0; i < listings?.length; i++) {
    const list = {
        rank: (
            <p><span style={{color : '#07B824'}}>{'//'}</span> {`${listings[i].rank}`}</p>
          ),
        bid: `${listings[i].bid}`,
        bidder: `${listings[i].bidder}`,
        genkis: `${listings[i].genkis}`,
        refund: `${listings[i].refund}`,
    };
    rows.push(list);
  }

  const columns = [
    { key: 'rank', label: 'RANK' },
    { key: 'bid', label: 'BID' },
    { key: 'bidder', label: 'BIDDER' },
    { key: 'genkis', label: 'GENKIS' },
    { key: 'refund', label: 'REFUND' },
  ];


  return (
    <div className={classes.root}>
      <BasicTable columns={columns} rows={rows} />
      <div className={classes.footer}>
        <p><span style={{color : '#03CE24'}}>/ /</span>    Winning Bids: <span style={{fontWeight : 'bold'}}>1342</span>    |    <span style={{color : '#760010'}}>X</span>     Losing Bids: <span style={{fontWeight : 'bold'}}>44231</span></p>
      </div>
    </div>
  );
};

export default RankTable;
