import { useStyles } from './style';
import { useEffect, useState } from 'react';
import { useWeb3React } from '@web3-react/core';
import toast from 'react-hot-toast';
import RankTable from './RankTable';
import ConnectModal from 'components/modal/connectModal/ConnectModal';
import AccountModal from 'components/modal/accountModal/AccountModal';
// import PageLoading from 'components/loading/PageLoading';
const rankData = [
  {
    rank : 1,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 2,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 3,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 4,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 5,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 6,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 7,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 8,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 9,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  {
    rank : 10,
    bid : 290.01,
    bidder : 'mojito.nft',
    genkis : 6,
    refund : 0.123
  },
  
]


const AuctionPage = () => {
  const classes = useStyles();
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showAcountModal, setShowAcountModal] = useState(false);
  const [isLoaded, setIsLoaded] = useState(true);
  const [count, setCount] = useState(0);
  const handleImageLoaded = () => {
    setCount(count + 1)
  }
  useEffect(() => {
    setIsLoaded(true);
    if (count >= 3){
      setTimeout(() => {
        setIsLoaded(false);
      }, 0);
    }
   
  }, [setIsLoaded, count]);

  const [mintCount, setMintCount] = useState(0);
  const decreaseHandle = () => {
    if (mintCount > 0) {
        setMintCount(mintCount - 1)
    }
}
const increaseHandle = () => {
    let mintLimit = 30;
    if (mintCount < mintLimit) {
        setMintCount(mintCount + 1)
    }
}
const [loginStatus, setLoginStatus] = useState(false);
const { connector, library, chainId, account, active } = useWeb3React();

useEffect(() => {
    const isLoggedin = account && active && chainId === parseInt(process.env.REACT_APP_NETWORK_ID, 10);
    setLoginStatus(isLoggedin);

}, [connector, library, account, active, chainId]);

const mintTokens = async () => {
  if (!loginStatus) {
      toast.error("Please connect wallet correctly!");
      return;
  }
 
};
  return (
    <>
    {/* <PageLoading isLoading={isLoaded} /> */}
      <div className={`${classes.root}`} >
        <img src="/assets/imgs/Mask.png" alt="" className={classes.bg1} onLoad = {handleImageLoaded}/>
        <img src="/assets/imgs/about_bg_01.png" alt="" className={classes.bg2} onLoad = {handleImageLoaded}/>
        
        <div className={classes.content}>

          <div className={classes.mintPart}>
          {loginStatus ? 
            <div className="state" style={{background : mintCount === 0 ? '#06680F' :'#680606'}}>
              <div className="price">
                <h4>ACTIVE BID</h4>
                <h3>0.04</h3>
              </div>
              <p><span>{'//'}</span> PLACE A BID</p>
            </div>:null}
            <div className="mintCount">
              {loginStatus ? 
                <>
                  <div className="row">
                      <button className="mintIncDec" disabled={false} onClick={decreaseHandle}>
                          <p><i className="fas fa-minus"></i></p>
                      </button>
                      <span className="mintCountValue" style={{}}>
                        <input type="number" value={mintCount}/>
                      </span>
                      <button className="mintIncDec" disabled={false} onClick={increaseHandle}>
                          <p><i className="fas fa-plus"></i></p>
                      </button>
                      <div className="eth"><img src="/assets/icons/eth_icon.svg" alt="" /></div>
                  </div>
                  <div className="row">
                    <div className="price">
                      <h4>Genkis:</h4>
                      <h3>1</h3>
                    </div>
                    <button className="mintNow" onClick={mintTokens} disabled={false}>
                      {mintCount === 0 ? 
                        <>
                          <p>INCREASE BID</p>
                          <img src="/assets/imgs/btn_03.png" alt=""   onLoad = {handleImageLoaded}/>
                        </>:
                        <>
                          <p>BID</p>
                          <img src="/assets/imgs/btn_02.png" alt=""   onLoad = {handleImageLoaded}/>
                        </>
                      }
                    </button>
                    <div className="price">
                      <h4>Refund:</h4>
                      <h3>0.01</h3>
                    </div>
                    </div>
                  <p className='desc'>Your bid must be at least 0.04 </p>
                </>:
                <>
                  <div className="row">
                    <button className="mintNow"  onClick={() => !loginStatus ? setShowConnectModal(true) : setShowAcountModal(true)}>
                        <p>CONNECT WALLET</p>
                        <img src="/assets/imgs/btn_02.png" alt=""   onLoad = {handleImageLoaded}/>
                    </button>
                  </div>
                </>}


                
            </div>
            <img src="/assets/imgs/Chibi Yami.png" alt="" className="banner"  onLoad = {handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
          </div>
          <div className={classes.tablePart} style = {{backgroundImage : `url('/assets/imgs/bg logo.png')`}}>
            <RankTable listings={rankData}/>
          </div>
        </div>

      </div>
      <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
      <AccountModal showAccountModal={showAcountModal} setShowAccountModal={setShowAcountModal} />
    </>
  );
};

export default AuctionPage;
