import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    borderRadius : 20,
    padding: 24,
    height : 'calc(100vh - 7rem)',
    position : 'relative',
    maxWidth : 1440,
    margin : 'auto',
    [theme.breakpoints.down('sm')]: {
      padding: 0,
      paddingTop: 0,
      paddingBottom: 50,
    },
  },
  content: {
    width: '90%',
    display: 'flex',
    margin : 'auto',
    height : '100%',
    alignItems: 'center',
    
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
    },
    
  },
  title: {
    background: '#ffffff00',
    margin: theme.spacing(0, 2),
    width: '60%',
    paddingTop: 10,
    paddingBottom: 10,
    display: 'flex',
    flexDirection: 'column',
    // flexWrap: 'wrap',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      alignItems: 'flex-start',
      width: '100%',
      zIndex :5,
    },
    '& h1': {
      fontSize : 'min(98px, 7vw)',
      lineHeight : 1,
      fontWeight : 700,
      color : '#fff',
      fontStyle : 'italic',
      fontFamily: "Montserrat-ExtraBold",
      [theme.breakpoints.down('xs')]: {
        fontSize : 46,
      },
    },
    '& .stroke': {
      color: 'transparent',
      textStroke: '1px #fff',
      textShadow : 'none',
      marginBottom: theme.spacing(2),
    },
    '& img': {
      height : 'min(98px, 7vw)',
      // width : 425,
      width : 'min(28vw, 425px)',
      objectFit : 'contain',
      [theme.breakpoints.down('xs')]: {
        width : 'min(65vw, 220px)',
        height : 40,
      },
    },
    '& p': {
      color : '#fff',
      width: '70%',
      fontSize: 14,
      lineHeight: '24px',
      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        width: '100%',
        fontSize : 12,
        marginTop : 20,
      },
    },
  },
  bottom: {
    position:'absolute',
    left : 0,
    bottom : 0,
    maxWidth : '50%',
    display: 'flex',
    zIndex : 4,
    [theme.breakpoints.down('xs')]: {
      width : '100vw',
      maxWidth : '100vw',
    },

    '& .left': {
      background : '#000',
      width : 400,
      maxWidth : '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      [theme.breakpoints.down('xs')]: {
        width : '50%',
      },
      '& p': {
        color : '#fff',
        fontWeight: 800,
        fontSize: 11,
        lineHeight: '26px',
        letterSpacing: '4px',
        '& span': {
          color : '#D71314',
        },
        [theme.breakpoints.down('xs')]: {
          letterSpacing: '2px',
        },
      },
    },
    '& .right': {
      position : 'relative',
      [theme.breakpoints.down('xs')]: {
        width : '50%',
      },
      '& .videoPlayBtndiv': {
        display: 'flex',
      },
      '& img': {
        height : '100%',
        objectFit : 'cover',
        [theme.breakpoints.down('xs')]: {
          height :'auto',
          width : '100%',
        },
      },
      '& .playBtn': {
        position:'absolute',
        height : 40,
        width : 40,
        left : '50%',
        top : '50%',
        zIndex : 1,
        transform : 'translate(-50%, -50%)',
        opacity : 0.6,
        transition :'all 0.7s ease',
        cursor : 'pointer',
        '&:hover': {
          opacity : 1,
        },
      },
    },
  },
  
  banner: {
    position:'absolute',
    left : '50%',
    bottom : 0,
    objectFit : 'cover',
    filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    zIndex : 4,
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '90vh',
    },
    [theme.breakpoints.down('lg')]: {
      bottom : '-12%',
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      bottom : 0,
      height : '60vh',
      transform : 'translateX(-50%)',
    },
  },
  banner_logo: {
    position:'absolute',
    // objectFit : '',
    width : '90%',
    // filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    height : '100vh',
    right : '0vw',
    top : '-5rem',
    zIndex : -2,
    [theme.breakpoints.down('xs')]: {
      height : 'auto',
      width : '140vw',
      right : '-20vw',
      bottom : '20vw',
      top : 'auto',
    },
  },
  backVideo: {
    width : 'calc(90% - 4px)',
    position:'absolute',
    objectFit : 'cover',
    height : '100vh',
    right : 2,
    top : '-5rem',
    zIndex : -3,
    [theme.breakpoints.down('xs')]: {
      height : 'auto',
      width : '160vw',
      right : '0px',
      bottom : '20vw',
      top : 'auto',
    },
  },
}));



export default useStyles;
