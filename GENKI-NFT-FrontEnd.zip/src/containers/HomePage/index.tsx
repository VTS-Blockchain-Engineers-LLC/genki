import ViewModal from 'components/modal/viewModal/ViewModal';
import { useEffect,  useState } from 'react';
import { useStyles } from './style';
// import PageLoading from 'components/loading/PageLoading';
const HomePage = () => {
  const classes = useStyles();
  const [showVideoModal, setShowVideoModal] = useState(false)

  const [isLoaded, setIsLoaded] = useState(true);
  const [count, setCount] = useState(0);
  const handleImageLoaded = () => {
    setCount(count + 1)
  }
  useEffect(() => {
    setIsLoaded(true);
    if (count === 5){
      setTimeout(() => {
        setIsLoaded(false);
      }, 0);
    }
   
  }, [setIsLoaded, count]);

  return (
    <>
    {/* <PageLoading isLoading={isLoaded} /> */}
      <div className={`${classes.root}`}>
        <div className={classes.content} >
          <div className={classes.title}>
            <h1>BRING THE</h1>
            <img src="/assets/imgs/energy.svg" alt=""  onLoad = {handleImageLoaded}/>
            <p>{'//'} Genki is an athletic brand powered by a collection of utility-backed PFP's.</p>
          </div>
          
          <img src="/assets/imgs/banner_01.png" alt="" className={classes.banner} onLoad = {handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
          <img src="/assets/imgs/bg_logo_02.png" alt="" className={classes.banner_logo} onLoad = {handleImageLoaded}/>
         
          <video className={classes.backVideo} autoPlay={true} loop muted={true} playsInline  style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}>
            <source src="/assets/genkiLoop.mp4" type="video/mp4"/>
          </video>
        </div>
        <div className={classes.bottom}>
            <div className="left">
              <p><span>{'//'}</span> THE GENKI VISION</p>
            </div>
            <div className="right">
              <div className='videoPlayBtndiv'>
                <img src="/assets/imgs/home_vidoe_img.png" alt=""  onLoad = {handleImageLoaded}/>
                <img src="/assets/imgs/btn_play.png" alt="" className="playBtn" onClick={()=>setShowVideoModal(true)} onLoad = {handleImageLoaded}/>
              </div>
            </div>
          </div>
      </div>
      <ViewModal showModal={showVideoModal} setShowModal = {setShowVideoModal}/>
    </>
  );
};

export default HomePage;
