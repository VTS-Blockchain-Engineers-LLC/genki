import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    borderRadius : 20,
    padding: 24,
    height : 'calc(100vh)',
    position : 'relative',
    margin : 'auto',
    background : '#000',
    [theme.breakpoints.down('sm')]: {
    },
  },
  content: {
    width: '90%',
    display: 'flex',
    margin : 'auto',
    height : '100%',
    alignItems: 'center',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
    },
    '& .logo': {
      position:'absolute',
      right : 30,
      top : 30,
      zIndex : 1,
      [theme.breakpoints.down('xs')]: {
        top : 10,
      },
      '& img': {
        height : 90,
        [theme.breakpoints.down('xs')]: {
          height : 60,
        },
      },
    },
    
  },

  bottom: {
    position:'absolute',
    left : '50%',
    bottom : 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
    transform : 'translateX(-50%)',
    [theme.breakpoints.down('xs')]: {
      width : '100vw',
      maxWidth : '100vw',
    },

    '& button': {
      background : '#fff',
      width : '20rem',
      height : '4.5rem',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border : '1px #fff solid',
      borderRadius : 15,
      transition : 'all 0.3s ease',
      cursor : 'pointer',
      marginBottom : 20,
      '&:hover': {
        boxShadow : '0px 0px 5px #fff',
      },
      [theme.breakpoints.down('xs')]: {
        width : '80vw',
      },
      '& p': {
        fontFamily: "'Barlow Condensed', sans-serif",
        fontWeight : 800,
        fontSize : 14,
        textTransform : 'uppercase',
        [theme.breakpoints.down('xs')]: {
        },
        '& small': {
          fontWeight : 600,
        }
      },
      '& div': {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        [theme.breakpoints.down('xs')]: {
        },
      },
      '& img': {
        height : 30,
        [theme.breakpoints.down('xs')]: {
          letterSpacing: '2px',
        },
      },
    },

  },
  myForm: {
    position:'absolute',
    left : '50%',
    height : '90vh',
    bottom : 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    transform : 'translateX(-50%)',
    
    [theme.breakpoints.down('xs')]: {
      width : '100vw',
      maxWidth : '100vw',
    },
    '& .formWrapper': {
      display: 'flex',
      flexDirection: 'column',
      overflowX : 'hidden',
      overflowY : 'scroll',
      height : 'calc(90vh - 8rem)',
      padding : 20,
      marginBottom : '1.5rem',
      gridArea : 'auto',
      gap : 30,
      [theme.breakpoints.down('xs')]: {
        alignItems: 'center',
        gap : 20,
      },
      '& h2': {
        color : '#fff',
        fontWeight : 700,
        fontSize : 30,
        textTransform : 'uppercase',
        [theme.breakpoints.down('xs')]: {
        },
        '& small': {
          fontWeight : 600,
        }
      },
    },

    '& button': {
      background : '#fff',
      width : '20rem',
      height : '4.5rem',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      border : '1px #fff solid',
      borderRadius : 15,
      transition : 'all 0.3s ease',
      cursor : 'pointer',
      marginBottom : 20,
      '&:hover': {
        boxShadow : '0px 0px 5px #fff',
      },
      [theme.breakpoints.down('xs')]: {
        width : '80vw',
      },
      '& p': {
        fontFamily: "'Barlow Condensed', sans-serif",
        fontWeight : 800,
        fontSize : 14,
        textTransform : 'uppercase',
        [theme.breakpoints.down('xs')]: {
        },
        '& small': {
          fontWeight : 600,
        }
      },
      '& div': {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        [theme.breakpoints.down('xs')]: {
        },
      },
      '& img': {
        height : 30,
        [theme.breakpoints.down('xs')]: {
          letterSpacing: '2px',
        },
      },
    },

  },
  socials: {
    right : 30,
    bottom : 30,
    zIndex : 1,
    display : 'flex',
    marginBottom : 20,
    gridArea : 'auto',
    gap : 30,
    [theme.breakpoints.down('xs')]: {
    },
    '& a':{
      display: 'flex',
      alignItems : 'center',
      justifyContent : 'center',
      color : '#fff',
      transition : 'all 0.7s ease',
      fontSize : '2rem',
      '&:hover':{
        color : '#888'
      },
      [theme.breakpoints.down('xs')]: {
        fontSize : '1.5rem',
      },
    }
  },
  banner: {
    position:'absolute',
    width : '100%',
    left : '0%',
    top : '50%',
    objectFit : 'cover',
    transition : 'all 1.5s ease',

    [theme.breakpoints.down('xs')]: {
      height :'170vh',
      top : '70%',
    },
  },
 
}));



export default useStyles;
