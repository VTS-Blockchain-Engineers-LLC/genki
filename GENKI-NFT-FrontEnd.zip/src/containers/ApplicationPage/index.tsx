import { useStyles } from './style';
import { useWeb3React } from '@web3-react/core';
import { useEffect, useState } from 'react';
import ConnectModal from 'components/modal/connectModal/ConnectModal';
import AccountModal from 'components/modal/accountModal/AccountModal';
import { truncateWalletString } from 'utils';
import TextInput from 'components/Forms/TextInput';
import ErrorAlert from 'components/Widgets/ErrorAlert';
import toast from 'react-hot-toast';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import { HashLink } from 'react-router-hash-link';
const ApplicationPage = () => {
  const classes = useStyles();
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showAcountModal, setShowAcountModal] = useState(false);

  const [loginStatus, setLoginStatus] = useState(false);
  const { connector, library, chainId, account, active } = useWeb3React();
  useEffect(() => {
    const isLoggedin = account && active && chainId === parseInt(process.env.REACT_APP_NETWORK_ID, 10);
    setLoginStatus(isLoggedin);
    
  }, [connector, library, account, active, chainId]);

  const [count, setCount] = useState(0);
  useEffect(() => {
    let myInterval = setInterval(() => {
      if (count < 19) {
        setCount(count + 1);
      }else{
        setCount(0);
      }
    }, 1000)
    return () => {
        clearInterval(myInterval);
    };
  }, [count, setCount]);


  const [startApplication, setStartApplication] = useState(false);

  const [formSubmit, setFormSubmit] = useState(false);
  const [discordName, setDiscordName] = useState(null);
  const [twitterName, setTwitterName] = useState(null);
  const [referralCode, setReferralCode] = useState(null);
  const [aboutMe, setAboutMe] = useState(null);
  const [sports, setSports] = useState(null);
  const [exerciseTime, setExerciseTime] = useState(null);
  const [upcomingProjects, setUpcomingProjects] = useState(null);
  const [nftCommunity, setNftCommunity] = useState(null);
  const [notableExperience, setNotableExperience] = useState(null);
  const [currentNFTMeta, setCurrentNFTMeta] = useState(null);


  const onSubmit = ()=>{
    setFormSubmit(true);
    if (!account || !library) {
      toast.error('Please connect your wallet correctly!');
      return;
    }

    if (!formSubmit || !discordName || !twitterName || !referralCode || !aboutMe || !aboutMe || !sports || !exerciseTime || !upcomingProjects || !nftCommunity || !notableExperience|| !currentNFTMeta) {
      toast.error('Please enter your answers correctly!');
      return;
    }
    
  }
  const isMobileOrTablet = useMediaQuery(`(max-width:640px)`);
  return (
    <>
      <div className={`${classes.root}`}>
        <div className={classes.content}>
          <div className="logo">
            <HashLink to="/">
              <img src="/assets/Genki_Logo_white 1.png" alt="" />
            </HashLink>
          </div>
          <img src="/assets/imgs/background_1.webp" alt="" className={classes.banner} style = {{ transform : startApplication && !isMobileOrTablet ? 'translateY(-100%)' : 'translateY(-50%)', opacity : count < 5 ? 1 : 0 }}/>
          <img src="/assets/imgs/background_2.webp" alt="" className={classes.banner} style = {{ transform : startApplication && !isMobileOrTablet ? 'translateY(-100%)' : 'translateY(-50%)', opacity : count >= 5 && count < 10 ? 1 : 0}}/>
          <img src="/assets/imgs/background_3.webp" alt="" className={classes.banner} style = {{ transform : startApplication && !isMobileOrTablet ? 'translateY(-100%)' : 'translateY(-50%)', opacity : count >= 10 && count < 15 ? 1 : 0}}/>
          <img src="/assets/imgs/background_4.webp" alt="" className={classes.banner} style = {{ transform : startApplication && !isMobileOrTablet ? 'translateY(-100%)' : 'translateY(-50%)', opacity : count >= 15 && count < 20 ? 1 : 0}}/>
        </div>

        {loginStatus && startApplication?
        <div className={classes.myForm}>
          <form action="" className="formWrapper">
            <h2>GENERAL INFO</h2>
            <TextInput 
              placeholder='Example: Genki#6969' 
              label={'What is your Discord username?'} 
              error={formSubmit && !discordName} 
              onChangeData={val => setDiscordName(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !discordName} />

            <TextInput 
              placeholder='Example: Genki_NFT' 
              label={"What is your Twitter Handle? "} 
              error={formSubmit && !twitterName} 
              onChangeData={val => setTwitterName(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !twitterName} />

            <TextInput 
              placeholder='Example: A123' 
              label={"Community Referral Code? (optional)"} 
              error={formSubmit && !referralCode} 
              onChangeData={val => setReferralCode(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !referralCode} />

            <h2>PERSONAL</h2>

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={'Tell us about yourself'} 
              error={formSubmit && !aboutMe} 
              onChangeData={val => setAboutMe(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !aboutMe} />

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={"What sports do you play/watch?"} 
              error={formSubmit && !sports} 
              onChangeData={val => setSports(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !sports} />

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={"How many times do you exercise per week?"} 
              error={formSubmit && !exerciseTime} 
              onChangeData={val => setExerciseTime(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !exerciseTime} />

            <h2>WEB3</h2>

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={'What upcoming project(s) are you looking forward to?'} 
              error={formSubmit && !upcomingProjects} 
              onChangeData={val => setUpcomingProjects(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !upcomingProjects} />

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={"Which NFT communities are you apart of?"} 
              error={formSubmit && !nftCommunity} 
              onChangeData={val => setNftCommunity(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !nftCommunity} />

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={"What has been the most notable experience of your time in web3?"} 
              error={formSubmit && !notableExperience} 
              onChangeData={val => setNotableExperience(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !notableExperience} />

            <TextInput 
              isMulti 
              placeholder='Write your answer here....' 
              label={"What would you change if you could change anything about the current NFT meta?"} 
              error={formSubmit && !currentNFTMeta} 
              onChangeData={val => setCurrentNFTMeta(val)}
            />
            <ErrorAlert title="Oops! Looks like you’re missing an answer or two." show={formSubmit && !currentNFTMeta} />
          </form>
          
          <button onClick={onSubmit} >
              <p>SUBMIT APPLICATION</p>
          </button>
          <div className={`${classes.socials}`}>
            <a href="http://twitter.com/" className="twitter" target="_blank" rel="noreferrer">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="http://discord.com/" className="discord" target="_blank" rel="noreferrer">
              <i className="fab fa-discord"></i>
            </a>
            
          </div>

          
        </div>:
        <div className={classes.bottom}>
          {loginStatus ? 
            <button onClick={() => setStartApplication(!startApplication)} >
                <p>Start Application</p>
            </button>:null}

          <button onClick={() => !loginStatus ? setShowConnectModal(true) : setShowAcountModal(true)} style = {{background : loginStatus ? '#00000000':'#fff'}}>
            {loginStatus ? 
              <>
              <div>
                <p  style = {{color : loginStatus ? '#fff':'#000'}}>Disconnect</p>
                <p  style = {{color : loginStatus ? '#fff':'#000'}}><small>{truncateWalletString(account)}</small></p>
              </div>
              </>:
              <>
              <img src="/assets/icons/Genki_Logomark_Black.png" alt="" />
              <p>Connect Wallet to Apply</p>
              </>
            }
          </button>
        </div>}
      </div>
      <ConnectModal showConnectModal={showConnectModal} setShowConnectModal={setShowConnectModal} />
      <AccountModal showAccountModal={showAcountModal} setShowAccountModal={setShowAcountModal} />
    </>
  );
};

export default ApplicationPage;
