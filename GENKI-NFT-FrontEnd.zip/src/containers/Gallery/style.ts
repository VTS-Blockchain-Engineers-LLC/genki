import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    height : '100%',
    width: '100%',
    maxWidth : 1440,
    margin : 'auto',
    paddingTop: 60,
    
    [theme.breakpoints.down('sm')]: {
      padding: 10,
      paddingTop: 0,
      paddingBottom: 50,
    },
  },
  top: {
    background: '#ffffff00',
    margin: theme.spacing(0, 2),
    width: 'calc(100% - 30px)',
    paddingTop: 10,
    paddingBottom: 10,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      alignItems: 'flex-start',
    },
    '& h1': {
      fontSize : 22,
      fontWeight : 500,

      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        fontSize : 20,
      },
    },
  },

  content: {
    width: '100%',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    alignItems: 'center',
    paddingTop: 10,
    [theme.breakpoints.down('xs')]: {
      paddingBottom: 20,
    },
    
  },
  masonry: {
    display: 'flex',
    width: '100%',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
    },
  },
  gridColumn: {
    margin: theme.spacing(0, 2),
    [theme.breakpoints.down('sm')]: {
      width: '100%',
    },
    [theme.breakpoints.down('xs')]: {
      margin: theme.spacing(0, 'auto'),
    },
  },
}));



export default useStyles;
