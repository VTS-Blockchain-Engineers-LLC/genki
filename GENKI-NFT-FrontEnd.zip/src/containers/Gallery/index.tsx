import { useStyles } from './style';
import Masonry from 'react-masonry-css';
import ProductCard1 from 'components/Cards/ProductCard1';
import { useEffect, useState } from 'react';
// import PageLoading from 'components/loading/PageLoading';

const topArts = [
  {
    assetUrl : '/assets/imgs/topGalley/bofu.jpg',
    id : 6517,
    name : 'Captain Bofu'
  },
  {
    assetUrl : '/assets/imgs/topGalley/yami.jpg',
    id : 4568,
    name : 'Captain Yami'
  },
  {
    assetUrl : '/assets/imgs/topGalley/kurai.jpg',
    id : 162,
    name : 'Captain Kurai'
  },
  {
    assetUrl : '/assets/imgs/topGalley/nagi.jpg',
    id : 548,
    name : 'Captain Nagi'
  },
  
]

const tmpData = [
  {
    assetUrl : '/assets/imgs/gallery/Genki_b16__0009_Layer_Comp_10.jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Genki_Batch4__0000_Layer_Comp_1.jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Genki_Batch4__0002_Layer_Comp_3.jpg',
  },

  {
    assetUrl : '/assets/imgs/gallery/Genki_female_sample_0000_Layer_Comp_1.jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Genki_Female_Sample_0001_Layer_Comp_2.jpg',
  },

  {
    assetUrl : '/assets/imgs/gallery/Genki_male_sample_0000_Layer_Comp_1.jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/IMG_6336.jpeg',
  },
  {
    assetUrl : '/assets/imgs/gallery/IMG_7501.jpeg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Untitled design (10).jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Untitled design (14).jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Untitled design (15).jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Untitled design (16).jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Untitled design (17).jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Genki_Soccer_Guy.jpg',
  },
  {
    assetUrl : '/assets/imgs/gallery/Untitled_design_9.jpg',
  },
]
const GalleryPage = () => {
  const classes = useStyles();

  const breakpointColumnsTop = {
    default: 4,
    2200: 4,
    1840: 4,
    1440: 4,
    1280: 4,
    768: 2,
    450: 2,
  };

  const breakpointColumnsObj = {
    default: 5,
    2200: 5,
    1840: 5,
    1440: 5,
    1280: 5,
    768: 4,
    450: 2,
  };
  const [myArt, setMyArt] = useState<any[]>([]);

  useEffect(() => {
    setMyArt(tmpData)
  }, []);

  // const [isLoaded, setIsLoaded] = useState(true);
  const [count, setCount] = useState(0);
  const handleImageLoaded = () => {
    setCount(count + 1)
  }
  // useEffect(() => {
  //   setIsLoaded(true);
  //   if (count >= (topArts.length + myArt.length - 1)){
  //     setTimeout(() => {
  //       setIsLoaded(false);
  //     }, 0);
  //   }
   
  // }, [setIsLoaded, count, myArt.length]);

  return (
    <>
    {/* <PageLoading isLoading={isLoaded} /> */}
      <div className={`${classes.root}`}>
        <div className={classes.content}>
          <Masonry
            breakpointCols={breakpointColumnsTop}
            className={classes.masonry}
            columnClassName={classes.gridColumn}
          >
            {topArts.map((d, i) => (
              <ProductCard1 key={i} item={d} onLoad={handleImageLoaded}/>
            ))}
          </Masonry>
          <Masonry
            breakpointCols={breakpointColumnsObj}
            className={classes.masonry}
            columnClassName={classes.gridColumn}
          >
            {myArt.map((d, i) => (
              <ProductCard1 key={i} item={d}onLoad={handleImageLoaded} />
            ))}
          </Masonry>
        </div>
      </div>
    </>
  );
};

export default GalleryPage;
