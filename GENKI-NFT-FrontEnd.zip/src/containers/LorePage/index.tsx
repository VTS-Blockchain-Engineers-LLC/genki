// import PageLoading from 'components/loading/PageLoading';
import { useEffect, useState } from 'react';
import { useStyles } from './style';

const LorePage = () => {
  const classes = useStyles();
  const [isLoaded, setIsLoaded] = useState(true);
  const [count, setCount] = useState(0);
  const handleImageLoaded = () => {
    setCount(count + 1)
  }
  useEffect(() => {
    setIsLoaded(true);
    if (count === 3){
      setTimeout(() => {
        setIsLoaded(false);
      }, 0);
    }
   
  }, [setIsLoaded, count]);
  return (
    <>
    {/* <PageLoading isLoading={isLoaded} /> */}
      <div className={`${classes.root}`} >
        <div className={classes.content}>
          <div className={classes.text}>
            <h3><span>{'//'}</span> THE LORE</h3>
            <h2>ONCE A YEAR, ATHLETES FROM EACH DISTRICT IN GENKI GATHER AT THE ARENA TO COMPETE IN THE <span>KI-GAMES.</span></h2>
            <p>The best of the best compete for the title in their respective sports. The KI-Games is a series of sporting events and competitions where competitors fight for fame, glory, and wealth but it comes at a cost.</p>

            <p>Factions are awarded with energy orbs based on their performances in every match they compete in. These energy orbs are used as currency as they are powerful omnipotent power sources. The orbs can be used to research body enhancement, revitalization, technology, and their limits are tested by scientists all over the world. They are the true embodiment of power and status in Genki. Will your district succeed in reaching the top?</p>
          </div>
          <h1 className={classes.bannerText}>ONCE A YEAR</h1>
          
          <img src="/assets/imgs/volleball girl.png" alt="" className={classes.bannerImg} onLoad = {handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
          <img src="/assets/imgs/logo_01.png" alt="" className={classes.bannerLogo} onLoad = {handleImageLoaded}/>
          <img src="/assets/imgs/lore_bg.png" alt="" className={classes.bannerBg} onLoad = {handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
        </div>
        
      </div>
    </>
  );
};

export default LorePage;
