import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    borderRadius : 20,
    padding: 24,
    height : 'calc(100vh - 7rem)',
    position : 'relative',
    maxWidth : 1440,
    margin : 'auto',
    [theme.breakpoints.down('sm')]: {
      padding: 10,
      paddingTop: 0,
      paddingBottom: 50,
    },
  },
  content: {
    width: '90%',
    display: 'flex',
    margin : 'auto',
    height : '100%',
    alignItems: 'center',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
    },
    
  },
  text: {
    background: '#ffffff00',
    margin: theme.spacing(0, 2),
    width: '60%',
    paddingTop: 10,
    paddingBottom: 10,
    display: 'flex',
    flexDirection: 'column',
    flexWrap: 'wrap',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
    },
    '& h3': {
      fontSize : 14,
      fontWeight : 800,
      color : '#fff',
      fontFamily: "'Montserrat', sans-serif",
      letterSpacing: '5px',
      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        fontSize : 14,
      },
      '& span': {
        color : '#D71314',
      },
    },
    '& h2': {
      fontSize : 20,
      fontWeight : 800,
      color : '#fff',
      fontFamily: "'Montserrat', sans-serif",
      // 

      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        fontSize : 20,
      },
      '& span': {
        background: 'linear-gradient(130.58deg, #F4D8CE -5.75%, #FFAA7F 37.34%, #FE7850 71.77%, #FF5656 83.17%, #FF4C4C 103.28%)',
        MozBackgroundClip : 'text',
        WebkitBackgroundClip: 'text',
        textFillColor: 'transparent',
      },
    },
    
    '& p': {
      color : '#CCCCCC',
      width: '80%',
      fontSize: 14,
      lineHeight: '25px',
      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        fontSize : 11,
        width: '100%',
      },
    },
  },
  bannerText: {
    position:'absolute',
    right : '5%',
    top : 'calc(50% - 8rem)',
    fontSize: '13.5vh',
    fontStyle : 'italic',
    color: 'transparent',
    textStroke: '1px #fff',
    textShadow : 'none',
    fontFamily: "Montserrat-ExtraBold",
    transform : 'rotate(90deg) translateY(-50%)',
    zIndex : 0,
    [theme.breakpoints.down('xs')]: {
      display : 'none',
    },

  },
  
  bannerImg: {
    position:'absolute',
    left : '60%',
    bottom : 0,
    objectFit : 'cover',
    height : '100vh',
    zIndex : -1,
    filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '100vh',
    },
    [theme.breakpoints.down('lg')]: {
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      display : 'none',
    },
  },
  bannerLogo: {
    position:'absolute',
    objectFit : 'cover',
    filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    height : '50vh',
    bottom : '10%',
    left : 0,
    zIndex : -2,
    [theme.breakpoints.down('xs')]: {
      paddingBottom: 20,
    },
  },
  bannerBg: {
    position:'absolute',
    objectFit : 'cover',
    filter : 'drop-shadow(0px 0px 15px #5c6d8988)',
    height : '45vh',
    left : '50%',
    transform : 'translateX(-50%)',
    top : 0,
    zIndex : -2,
    [theme.breakpoints.down('xs')]: {
      display : 'none',
    },
  },
}));



export default useStyles;
