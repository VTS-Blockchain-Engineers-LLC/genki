import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
  root: {
    height : '100%',
    width: '100%',
    [theme.breakpoints.down('sm')]: {
      padding: 0,
      paddingTop: 0,
    },
  },
  bg1: {
    position:'absolute',
    left : '50%',
    top : 0,
    zIndex : -1,
    width : '100%',
    transform : 'translateX(-50%)',
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '100vh',
    },
    [theme.breakpoints.down('lg')]: {
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      paddingBottom: 20,
    },
  },
  bg2: {
    position:'absolute',
    left : '50%',
    top : 0,
    objectFit : 'cover',
    width : '100%',
    zIndex : -1,
    transform : 'translateX(-50%)',
    [theme.breakpoints.up('xl')]: {
      bottom : 0,
      height : '100vh',
    },
    [theme.breakpoints.down('lg')]: {
      height : '100vh',
    },
    [theme.breakpoints.down('xs')]: {
      paddingBottom: 20,
    },
  },
  top: {
    background: '#ffffff00',
    width: 'calc(100%)',
    height : 'calc(100vh - 6em)',
    marginTop : '1rem',
    marginBottom : '5rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      alignItems: 'flex-start',
      marginTop : '2rem',
    },
    '& h1': {
      fontSize : 22,
      fontWeight : 500,

      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        fontSize : 20,
      },
    },
    '& .banner': {
      height : 'calc(80%)',
      [theme.breakpoints.down('xs')]: {
        transform : 'translateX(-30%)'
      },
    },
    '& .pc': {
      display: 'flex',
      [theme.breakpoints.down('xs')]: {
        display: 'none !important',
      },
    },
    '& .mob': {
      display: 'none !important',
      [theme.breakpoints.down('xs')]: {
        display: 'flex !important',
      },
    },
  },
  title: {
    background: '#ffffff00',
    width: '100%',
    paddingTop: 10,
    paddingBottom: 10,
    display: 'flex',
    alignItems: 'center',
    flexDirection: 'column',
    [theme.breakpoints.down('xs')]: {
      flexDirection: 'column',
      alignItems: 'center',
    },
    '& h1': {
      fontSize : 'min(40px, 4vw)',
      lineHeight : 1,
      fontWeight : 700,
      color : '#fff',
      letterSpacing: 5,
      fontFamily: "Montserrat-ExtraBold",
      [theme.breakpoints.down('xs')]: {
        fontSize : 32,
        textAlign : 'center',
        lineHeight : '52px',
        width : '90%',
      },
    },
    '& .stroke': {
      color: 'transparent',
      textStroke: '1px #fff',
      textShadow : 'none',
      marginBottom: theme.spacing(2),
    },
    '& .strokeImg': {
      [theme.breakpoints.down('xs')]: {
        height : 80,
      },
    },
  },
  content: {
    width: '80%',
    display: 'flex',
    flexDirection: 'column',
    paddingTop: 70,
    maxWidth : 1440,
    margin : 'auto',
    marginBottom : '5rem',
    position : 'relative',
    [theme.breakpoints.down('xs')]: {
      padding : 10,
      width: '100%',
      marginBottom : '2rem',
    },
    '& h2': {
      fontSize : 14,
      lineHeight : 1,
      fontWeight : 700,
      color : '#fff',
      letterSpacing: 5,
      fontFamily: "Montserrat-ExtraBold",
      marginLeft : 16,
      marginBottom : '3rem',
      [theme.breakpoints.down('xs')]: {
        fontSize : 16,
        marginLeft : 0,
        textAlign :'center',
      },
      '& span': {
        color : '#D71314',
      }
      
    },
    '& .stroke': {
      fontSize : 164,
      lineHeight : 1,
      fontWeight : 700,
      fontStyle : 'italic',
      fontFamily: "Montserrat-ExtraBold",
      color: 'transparent',
      textStroke: '1px #fff',
      textShadow : 'none',
      whiteSpace : 'nowrap',
      opacity : 0.1,
      position : 'absolute',
      left : '50%',
      top : 0,
      transform : 'translateX(-50%)',
      marginBottom: theme.spacing(2),
      [theme.breakpoints.down('xs')]: {
        display: 'none',
      },
    },
  },
  partners: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginTop : 30,
    [theme.breakpoints.down('xs')]: {
      marginTop : 0,
      flexDirection: 'column',
    },
    '& a': {
      maxWidth : '30%',
      [theme.breakpoints.down('xs')]: {
        maxWidth : '70%',
        marginBottom : 30,
      },
      '&:hover': {
        transition :'all 0.7s ease',
        '& img': {
          opacity : 0.5,
        }
      },
      '& img': {
        maxWidth : '100%',
        transition :'all 0.7s ease',
        [theme.breakpoints.down('xs')]: {
        },
      }
    }
  },
  masonry: {
    display: 'flex',
    width: '100%',
    [theme.breakpoints.down('xs')]: {
      width: '100%',
    },
  },
  gridColumn: {
    margin: theme.spacing(0, 2),
    [theme.breakpoints.down('sm')]: {
      width: '100%',
    },
    [theme.breakpoints.down('xs')]: {
      margin: theme.spacing(0, 1),
    },
  },
}));



export default useStyles;
