import { useStyles } from './style';
import Masonry from 'react-masonry-css';
import TeamCard from 'components/Cards/TeamCard';
import Footer from 'components/Layout/Footer/Footer';
// import PageLoading from 'components/loading/PageLoading';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
const founerTeam = [
  {
    assetUrl : '/assets/imgs/founter_team_01.jpg',
    id : '@FrankyWWL',
    title : 'CO-FOUNDER // CANADA',
    name : 'FRANKY',
    link : 'https://twitter.com/FrankyWWL',
  },
  {
    assetUrl : '/assets/imgs/founter_team_02.jpg',
    id : '@IrmanBurr',
    title : 'CO-FOUNDER // TORONTO, CANADA',
    name : 'IRMAN BUTTAR',
    link : 'https://twitter.com/IrmanBurr',
  },
  {
    assetUrl : '/assets/imgs/founter_team_03.jpg',
    id : '@oCubann',
    title : 'CO-FOUNDER // NY, USA',
    name : 'TYLER GARCIA',
    link : 'https://twitter.com/oCubann',
  },
  {
    assetUrl : '/assets/imgs/founter_team_04.jpg',
    id : '@CryptoTomYT',
    title : 'CO-FOUNDER // BAY AREA, USA',
    name : 'TOM',
    link : 'https://twitter.com/CryptoTomYT',
  },
  
]

const coreTeam = [
  {
    assetUrl : '/assets/imgs/Genki_1of1_Datboi.jpg',
    name : 'JONNY',
    title : 'COMMUNITY LEAD ',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Dom.jpg',
    name : 'DOM',
    title : 'COMMUNITY MANAGER',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Jay.jpg',
    name : 'JAY',
    title : 'BOARD OF COUNCIL',
  },
  {
    assetUrl : '/assets/imgs/mav.jpg',
    name : 'MAVERICK',
    title : 'BOARD OF COUNCIL',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Riz.jpg',
    name : 'RIZ',
    title : 'BOARD OF COUNCIL',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Boquet.jpg',
    name : 'BOQUET',
    title : 'AMBASSADOR',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Goldilocks.jpg',
    name : 'GOLDILOCKS',
    title : 'AMBASSADOR',
  },
  {
    assetUrl : '/assets/imgs/chewwy.jpg',
    name : 'CHEWTORO',
    title : 'AMBASSADOR',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Prada.jpg',
    name : 'PRADA',
    title : 'ADVISOR',
  },
  {
    assetUrl : '/assets/imgs/FRIDGE.jpg',
    name : 'FRIDGE',
    title : 'ADVISOR',
  },
]

const athletextTeam = [
  {
    assetUrl : '/assets/imgs/Genki_1of1_CamJordan.jpg',
    name : 'CAMERON JORDAN',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Joe.jpg',
    name : 'JOE JONES',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/PAT OC.jpeg',
    name : 'PAT O’CONNOR',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/DARE.jpg',
    name : 'DARE OGUNBOWALE',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Mark.jpg',
    name : 'MARK INGRAM',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/MARLON.jpg',
    name : 'MARLON HUMPHREY',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/ARIKE.jpg',
    name : 'ARIKE OGUNBOWALE',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/SATOU.jpg',
    name : 'SATOU SABALLY',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/Genki_1of1_Patrick.jpg',
    name : 'PATRICK PATERSON',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/TAYLOR.jpg',
    name : 'TAYLOR WALLS',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/GRABS.jpg',
    name : 'MICHAEL GRABNER',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/STEFAN.jpg',
    name : 'STEFAN NOESEN',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/KINKS.jpg',
    name : 'KEITH KINKAID',
    title : 'NFL',
  },
  {
    assetUrl : '/assets/imgs/BRENT.jpg',
    name : 'BRENT URBAN',
    title : 'NFL',
  },
  
]

const devPartners = [
  {
    assetUrl : '/assets/imgs/dev/brollyholly.jpg',
    id : '@BrollyHollyNo',
    name : 'BrollyHolly ',
    link : 'https://twitter.com/BrollyHollyNo',
    link1 : 'https://twitter.com/VoidZeroLabs',
  },
  {
    assetUrl : '/assets/imgs/dev/micah headshot.jpg',
    id : '@micahcruver',
    name : 'Micah Cruver',
    link : 'https://twitter.com/micahcruver',
    link1 : 'https://twitter.com/VoidZeroLabs',
  },
  {
    assetUrl : '/assets/imgs/dev/inetdave pfp.jpg',
    id : '@inetdave',
    name : 'INetDave',
    link : 'https://twitter.com/inetdave',
    link1 : 'https://twitter.com/VoidZeroLabs',
  },
]


const AboutPage = () => {
  const classes = useStyles();
  const [isLoaded, setIsLoaded] = useState(true);
  const [count, setCount] = useState(0);
  const handleImageLoaded = () => {
    setCount(count + 1)
  }
  useEffect(() => {
    setIsLoaded(true);
    if (count >= founerTeam.length + coreTeam.length + athletextTeam.length + devPartners.length - 1 ){
      setTimeout(() => {
        setIsLoaded(false);
      }, 0);
    }
   
  }, [setIsLoaded, count]);

  const breakpointColumnsTop = {
    default: 4,
    2200: 4,
    1840: 4,
    1440: 4,
    1280: 4,
    768: 2,
    450: 1,
  };
  const breakpointColumnsDev = {
    default: 3,
    2200: 3,
    1840: 3,
    1440: 3,
    1280: 3,
    768: 1,
    450: 1,
  };

  const breakpointColumnsObj = {
    default: 5,
    2200: 5,
    1840: 5,
    1440: 5,
    1280: 5,
    768: 4,
    450: 2,
  };
  return (
    <>
      {/* <PageLoading isLoading={isLoaded} /> */}
      <div className={`${classes.root}`} >
        <img src="/assets/imgs/Mask.png" alt="" className={classes.bg1} onLoad={handleImageLoaded} />
        <img src="/assets/imgs/about_bg_01.png" alt="" className={classes.bg2} onLoad={handleImageLoaded} />
        <div className={classes.top}>
          <div className={classes.title}>
            <h1>MEET THE TEAM MAKING</h1>
            <img src="/assets/imgs/GENKI A REALITY_01.png" alt="" className='strokeImg mob' onLoad={handleImageLoaded}/>
            <img src="/assets/imgs/GENKI A REALITY.png" alt="" className='strokeImg pc' onLoad={handleImageLoaded} />
          </div>
          <img src="/assets/imgs/about_banner_01.png" alt="" className='banner mob' onLoad={handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
          <img src="/assets/imgs/about_banner.png" alt="" className='banner pc' onLoad={handleImageLoaded} style = {{opacity : isLoaded ? 0 : 1, transition : 'all 0.3s ease'}}/>
        </div>
        <div className={classes.content}>
          <h1 className='stroke'>FOUNDING TEAM</h1>
          <h2><span>{'//'}</span>  FOUNDING TEAM</h2>
          <Masonry
            breakpointCols={breakpointColumnsTop}
            className={classes.masonry}
            columnClassName={classes.gridColumn}
          >
            {founerTeam.map((d, i) => (
              <TeamCard key={i} item={d}  onLoad={handleImageLoaded}/>
            ))}
          </Masonry>
          
        </div>

        <div className={classes.content}>
          <h1 className='stroke' style={{fontSize : 185, top : -20}}>CORE TEAM</h1>
          <h2><span>{'//'}</span>  CORE TEAM</h2>
          
          <Masonry
            breakpointCols={breakpointColumnsObj}
            className={classes.masonry}
            columnClassName={classes.gridColumn}
          >
            {coreTeam.map((d, i) => (
              <TeamCard key={i} item={d} onLoad={handleImageLoaded}/>
            ))}
          </Masonry>
        </div>

        <div className={classes.content}>
          <h1 className='stroke' style={{fontSize : 185, top : -20}}>ATHLETES</h1>
          <h2><span>{'//'}</span>  ATHLETES</h2>
          
          <Masonry
            breakpointCols={breakpointColumnsObj}
            className={classes.masonry}
            columnClassName={classes.gridColumn}
          >
            {athletextTeam.map((d, i) => (
              <TeamCard key={i} item={d} onLoad={handleImageLoaded}/>
            ))}
          </Masonry>
        </div>

        <div className={classes.content}>
          <h1 className='stroke' style={{fontSize : 185, top : -20}}>DEV PARTNERS</h1>
          <h2><span>{'//'}</span>  Creative + Dev Partners</h2>
          
          <Masonry
            breakpointCols={breakpointColumnsDev}
            className={classes.masonry}
            columnClassName={classes.gridColumn}
          >
            {devPartners.map((d, i) => (
              <TeamCard key={i} item={d} onLoad={handleImageLoaded}/>
            ))}
          </Masonry>
        </div>

        <div className={classes.content}>
          <h1 className='stroke' style={{fontSize : 185, top : -20}}>PARTNERS </h1>
          <h2><span>{'//'}</span>  PARTNERS</h2>
          
          <div className={classes.partners}>
            <Link to="#" ><img src="/assets/icons/partner_01.svg" alt="" /></Link>
            <Link to="#" ><img src="/assets/icons/partner_02.svg" alt="" /></Link>
            <Link to="#" ><img src="/assets/icons/partner_03.svg" alt="" /></Link>
            {/* <a href="/" target={'_blank'}><img src="/assets/icons/partner_01.svg" alt="" /></a>
            <a href="/" target={'_blank'}><img src="/assets/icons/partner_02.svg" alt="" /></a>
            <a href="/" target={'_blank'}><img src="/assets/icons/partner_03.svg" alt="" /></a> */}
          
          </div>
        </div>
        <Footer/>
      </div>
    </>
  );
};

export default AboutPage;
