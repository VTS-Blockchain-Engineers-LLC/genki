import '@ethersproject/shims';
import { ethers } from 'ethers';
import toast from 'react-hot-toast';
import { getContractObj } from '.';

export async function approveToken(chainId, provider, account, _limitAmount) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);

  const allowanceAmount = await QUINTContract.allowance(account, nftContract.address);
  const QUINTDecimals = await QUINTContract.decimals();

  if (allowanceAmount.lt(ethers.utils.parseUnits(_limitAmount.toString(), QUINTDecimals))) {
    const load_approve_toast_id = toast.loading(`Please wait, QUINT is approving now...`);
    try {
      var tx = await QUINTContract.approve(nftContract.address, ethers.constants.MaxUint256);
      await tx.wait(1);
    } catch (e) {
      console.log(e);
    }
    toast.dismiss(load_approve_toast_id);
  }

}

export async function mintFixed(chainId, provider, _tokenURI, _price, _royalty) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  try {
    const QUINTDecimals = await QUINTContract.decimals();
    const tx = await nftContract.mintFixed(_tokenURI, QUINTContract.address, _royalty, ethers.utils.parseUnits(_price.toString(), QUINTDecimals));
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function mintAuction(chainId, provider, _tokenURI, _minBidPrice, _startTime: Date, _endTime: Date, _royalty) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  const startUnixTimeStamp = Math.round(_startTime.getTime() / 1000);
  const endUnixTimeStamp = Math.round(_endTime.getTime() / 1000);
  try {
    const QUINTDecimals = await QUINTContract.decimals();
    const tx = await nftContract.mintAuction(_tokenURI, QUINTContract.address, _royalty, ethers.utils.parseUnits(_minBidPrice.toString(), QUINTDecimals), startUnixTimeStamp, endUnixTimeStamp);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function mintUnlimitedAuction(chainId, provider, _tokenURI, _royalty) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  try {
    const tx = await nftContract.mintUnlimitedAuction(_tokenURI, QUINTContract.address, _royalty);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function buy(chainId, provider, account, _tokenID, _price) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    await approveToken(chainId, provider, account, _price);
    const tx = await nftContract.buyWithToken(_tokenID);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function sell(chainId, provider, _tokenID, _buyer) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const tx = await nftContract.sell(_tokenID, _buyer);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function bid(chainId, library, provider, account, _tokenID, _price) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  try {
    await approveToken(chainId, provider, account, _price);

    const QUINTDecimals = await QUINTContract.decimals();
    const balanceQUINT = await QUINTContract.balanceOf(account);
    const bidTokenAmount = ethers.utils.parseUnits(_price.toString(), QUINTDecimals)

    if (balanceQUINT.lt(bidTokenAmount)) return false;

    const load_bid_toast_id = toast.loading(`Plesae wait until send bid offer...`);
    const placeBidToNFT = await nftContract.bid(_tokenID, bidTokenAmount);
    await placeBidToNFT.wait(1);
    toast.dismiss(load_bid_toast_id);

    return true;
  } catch (e) {
    toast.dismiss();
    console.log(e);
    return false;
  }
}

export async function cancelBid(chainId, provider, _tokenID) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const tx = await nftContract.cancelBid(_tokenID);
    await tx.wait(1);
    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function burn(chainId, provider, _tokenID) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const tx = await nftContract.burn(_tokenID);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function listFixed(chainId, provider, _tokenID, _price, _royalty) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  try {
    const QUINTDecimals = await QUINTContract.decimals();
    const tx = await nftContract.listFixed(_tokenID, QUINTContract.address, _royalty, ethers.utils.parseUnits(_price.toString(), QUINTDecimals));
    await tx.wait(1);

    return true;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function listAuction(chainId, provider, _tokenID, _minBidPrice, _startTime, _endTime, _royalty) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  const startUnixTimeStamp = Math.round(_startTime.getTime() / 1000);
  const endUnixTimeStamp = Math.round(_endTime.getTime() / 1000);
  try {
    const QUINTDecimals = await QUINTContract.decimals();
    const tx = await nftContract.listAuction(_tokenID, QUINTContract.address, _royalty, ethers.utils.parseUnits(_minBidPrice.toString(), QUINTDecimals), startUnixTimeStamp, endUnixTimeStamp);
    await tx.wait(1);

    return true;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function listUnlimitedAuction(chainId, provider, _tokenID, _royalty) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  try {
    const tx = await nftContract.listUnlimitedAuction(_tokenID, QUINTContract.address, _royalty);
    await tx.wait(1);

    return true;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function claimAuction(chainId, provider, _tokenID) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const tx = await nftContract.claimAuction(_tokenID);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}

export async function disableListing(chainId, provider, _tokenID) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const tx = await nftContract.disableListing(_tokenID);
    await tx.wait(1);

    return tx.hash;
  } catch (e) {
    console.log(e);
    return false;
  }
}


export async function getFeePercent(chainId, provider) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const feePercent = await nftContract.feePercent();
    return parseFloat(feePercent.toString());
  } catch (e) {
    console.log(e);
    return 0;
  }
}

export async function getBalanceOfQUINT(chainId, provider, account) {
  const QUINTContract = getContractObj('QUINT', chainId, provider);
  try {
    const QUINTDecimals = await QUINTContract.decimals();
    const balanceQUINT = await QUINTContract.balanceOf(account);
    return parseFloat(ethers.utils.formatUnits(balanceQUINT, QUINTDecimals));
  } catch (e) {
    console.log(e);
    return 0;
  }
}

export async function getBalanceOfBNB(library, account) {
  try {
    const balanceBNB = await library.getBalance(account);
    return parseFloat(ethers.utils.formatEther(balanceBNB));
  } catch (e) {
    console.log(e);
    return 0;
  }
}

export async function getAllowedMint(chainId, provider, account) {
  const nftContract = getContractObj('QUINTNFT', chainId, provider);
  try {
    const enablePublic = await nftContract.enablePublicMint();
    if (enablePublic === true) return true;
    const enableUser = await nftContract.mapUserEnableForMint(account);
    return enableUser
  } catch (e) {
    console.log(e);
    return false;
  }
}
